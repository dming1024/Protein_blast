### IMPORTANT NOTICE ###

As of Ensembl release 89 (May 2017), VEP is no longer available as part of the ensembl-tools repository.

VEP is now available in the ensembl-vep repository: https://github.com/Ensembl/ensembl-vep

Documentation: http://www.ensembl.org/info/docs/tools/vep/script/index.html

Previous versions of VEP are available in release branches of ensembl-tools:

git clone https://github.com/Ensembl/ensembl-tools.git
cd ensembl-tools/scripts/variant_effect_predictor
git checkout release/88
